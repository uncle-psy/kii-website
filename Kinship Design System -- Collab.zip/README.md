# Kinship Design System

A small, opinionated design system for Kinship — a movement-funding platform where creators launch projects and communities back them on-chain. Dark-UI native. Serif-display, sans-body. Warm orange pulse on deep navy.

> *Ownership matters. So do you.*

---

## Orientation

This is a **living design system** captured as a single CSS file + a folder of HTML preview cards. It is not a component library you install — it is a reference you read, copy from, and extend. If you are building a new Kinship surface (a landing page, an onboarding flow, an email, a slide deck), start by reading this file and linking `colors_and_type.css`.

**Files at a glance**
- [`colors_and_type.css`](./colors_and_type.css) — tokens + base styles. Import this into everything.
- [`UI Kit.html`](./UI%20Kit.html) — a full worked example: nav, hero, stat strip, movement cards, activity feed, pricing.
- [`preview/`](./preview) — one HTML card per design-system concept (colors, type, spacing, components, logos). These are the review artifacts.
- [`assets/`](./assets) — Kinship logo lockups (SVG + PNG, every colorway).
- [`fonts/`](./fonts) — Goudy Heavyface + Avenir (Light / Book / Regular / Heavy / Black).
- [`SKILL.md`](./SKILL.md) — the skill prompt: *how to design in the Kinship idiom*.

---

## Visual foundations

### The three-word aesthetic

**Deep. Warm. Optimistic.** Kinship lives on a near-black deep navy (`#09073A`), with a single pulse of brand orange (`#EB8000`) for anything the user should touch. Sky blue (`#03CCD9`) is the secondary accent — used for links, for on-chain signal, and occasionally for whole hero lockups. Cream (`#FFFFE6 / #F9DDB7`) anchors print and light-theme surfaces.

Avoid: cold greys, neon gradients for the sake of gradient, emoji as primary iconography, flat pastel color fields. The palette is warm and *earned* — it comes from umber, gold, and sky.

### Typography

Goudy Heavyface (display) + Avenir (body). Goudy has a tall x-height, heavy stroke, and a distinctive italic — it carries every headline. Avenir is the quiet, humanist counterpoint that handles everything else.

**The signature move: `em.kin-emph`** — one italic Goudy phrase, set in the brand orange, inside a display headline. *One phrase per headline, never two.* Examples in `preview/type-emphasis.html`.

### Rhythm

- 4pt spacing grid; 8/12/16/20/24 do most of the work.
- Pill-shaped nav and badges (`--radius-pill`); **buttons are squared with a slight radius** (`--radius-xs`, 4px). Cards use `--radius-lg` (14px).
- Shadows are cool and dim on dark surfaces — never bright. `--shadow-glow-accent` and `--shadow-glow-sky` are reserved for *one* hero CTA per screen.

---

## Content fundamentals

**Voice.** Warm, direct, slightly literary. Short sentences. We write *to* the reader, not around them. We use "you" freely. We almost never use "users" — we say *creators*, *backers*, *the block*, *kin*.

**Headline pattern.** A complete thought, then an italic Goudy phrase that reframes it:
- *"Ownership matters. So do you."*
- *"Launch a movement the right way."*
- *"A feed, but kinder."*

**Avoid.** Buzzwords (*synergy*, *leverage*, *disrupt*), hollow CTAs (*Learn more*), stacked emoji, web3 jargon that isn't load-bearing (*DYOR*, *GM*). If we use "on-chain" or "$KIN", it has to mean something in the sentence.

**Numbers.** Always display in Goudy. Always round to three significant figures in dense UI (`$81.4k`, not `$81,437`). Use the comma for full precision in detail views.

---

## Iconography

Kinship does **not** ship an icon set. We use:
1. **Text arrows** (`→`, `↗`, `←`) as the default "continue" glyph in CTAs.
2. **Lucide** (`lucide.dev`) when a glyph is genuinely necessary — stroke 1.75, 20px default size, rendered in `currentColor`. Never colored, never filled.
3. **Placeholders** for anything else, until a designer draws a real one. A good placeholder is better than a wrong icon.

Logo usage: see `preview/logo-lockups.html`. On navy and umber, use white or sky blue. On sky and orange, use dark blue. Never recolor the logo to accent pink or gold.

---

## Components (preview index)

| Concept | Card |
|---|---|
| Brand palette | [`preview/colors-brand.html`](./preview/colors-brand.html) |
| Accent + feedback colors | [`preview/colors-accents.html`](./preview/colors-accents.html) |
| Semantic tokens (dark) | [`preview/colors-semantic.html`](./preview/colors-semantic.html) |
| Display type (Goudy) | [`preview/type-display.html`](./preview/type-display.html) |
| Body type (Avenir) | [`preview/type-body.html`](./preview/type-body.html) |
| The signature emphasis | [`preview/type-emphasis.html`](./preview/type-emphasis.html) |
| Spacing · Radius · Elevation | [`preview/spacing.html`](./preview/spacing.html) |
| Buttons | [`preview/buttons.html`](./preview/buttons.html) |
| Inputs | [`preview/inputs.html`](./preview/inputs.html) |
| Cards | [`preview/cards.html`](./preview/cards.html) |
| Badges + chips | [`preview/badges.html`](./preview/badges.html) |
| Logo — primary | [`preview/logo-primary.html`](./preview/logo-primary.html) |
| Logo — lockups | [`preview/logo-lockups.html`](./preview/logo-lockups.html) |

---

## How to use

```html
<link rel="stylesheet" href="/path/to/colors_and_type.css">
```

Then use tokens everywhere:

```css
.hero {
  background: linear-gradient(135deg, var(--surface-elev), var(--bg));
  color: var(--fg);
  border-radius: var(--radius-xl);
  padding: var(--space-16) var(--space-12);
  box-shadow: var(--shadow-lg);
}

.hero h1 {
  font-family: var(--font-display);
  font-size: var(--fs-5xl);
}

.hero h1 em { /* the signature move */
  font-family: var(--font-display);
  font-style: italic;
  color: var(--accent);
}
```

For a full worked example, open `UI Kit.html`.
