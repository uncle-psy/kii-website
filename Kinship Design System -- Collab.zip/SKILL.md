# SKILL: Design in the Kinship idiom

Use this skill whenever you're creating a Kinship surface — landing pages, product screens, onboarding flows, decks, emails, prototypes. It loads the design system's visual vocabulary so your output looks native to Kinship, not generic.

## Start every Kinship design with

1. **Link the stylesheet.** Every HTML file must `<link rel="stylesheet" href="colors_and_type.css">` (path adjusted). Never redefine brand colors or fonts inline — always use the CSS variables.
2. **Read `README.md`** for the content voice + the signature emphasis pattern before writing copy.
3. **Open `UI Kit.html`** as a structural reference for what a finished Kinship page looks like. Mimic its rhythm (hero → stat strip → cards → activity → pricing) unless the brief says otherwise.

## The five moves that make it look Kinship

1. **Deep navy field.** `var(--bg-deep)` (#03011B) or `var(--bg)` (#09073A) is the page. Cards sit on `var(--surface)` (#0A0D33). Never default to black; never default to grey.
2. **One pulse of orange.** `var(--accent)` (#EB8000) is reserved for the single thing the user should touch. If you have two primary buttons on screen, you have an error.
3. **Goudy display + italic orange emphasis.** Every meaningful headline uses `var(--font-display)`. The *one* italic-orange phrase per headline is the house rhetorical move — see `em.kin-emph` in `colors_and_type.css`.
4. **Numbers in Goudy.** Every stat, price, count, progress number is Goudy (not Avenir). It's the primary visual signal that data is *alive*.
5. **Sky blue for linkage and on-chain signal.** `var(--kin-skyblue)` (#03CCD9) goes on links, wallet states, eyebrow labels in hero sections, and the primary logo on navy.

## Colors — pick from these, don't invent

- Surfaces: `--bg-deep`, `--bg`, `--surface`, `--surface-elev`
- Text: `--fg`, `--fg-muted`, `--fg-soft`, `--fg-dim`
- Action: `--accent`, `--accent-hover`
- Accent: `--kin-skyblue`, `--kin-magenta`, `--kin-gold`, `--kin-lime` (sparingly; one per screen)
- Feedback: `--success`, `--danger`, `--kin-warning`

Warm accents (`--kin-accent-chocobrown`, `--kin-accent-chestnut`, `--kin-accent-rusticbrown`, `--kin-darkumber`) are for imagery backgrounds and editorial moments, not UI chrome.

## Type rules

- H1: `var(--fs-5xl)` (54) to `var(--fs-6xl)` (72), Goudy, line-height ~1.
- H2: 30–40px Goudy.
- Eyebrow: 10–11px Avenir 700, caps, `letter-spacing: 0.16em`, in `--fg-soft` or `--kin-skyblue`.
- Body: 16px Avenir 400, `var(--fg-muted)`.
- Small: 12–14px, `var(--fg-soft)`.
- Mono: used for kickers and small numeric metadata (timestamps, token IDs).

## Components — use the patterns from `preview/`

- **Buttons:** squared with a slight radius (`--radius-xs`, 4px). Primary = orange. Secondary = transparent + border. Sky = reserved for wallet/connect actions.
- **Cards:** `--surface`, `--radius-lg`, `--shadow-md`. Movement cards have a colored cover (radial gradient in a single brand hue) + metadata.
- **Stat strips:** horizontal 4-cell grid on `surface-elev`, numbers in Goudy at 44px, delta in `--kin-complete` green.
- **Badges:** pill, 11px caps, colored background with matching colored text at alpha ~0.14 bg / 1.0 text.

## Things to avoid

- Generic SaaS gradients (purple-to-pink, teal-to-cyan).
- Emoji as UI iconography.
- Blue primary buttons. Orange only.
- Two italic emphases in one headline. One.
- Drawing custom SVG illustrations inline — use placeholders or ask for real artwork.
- Inter, Roboto, or system fonts. Avenir is required for body; Goudy is required for display.

## Before you finish

- Does at least one headline have `em.kin-emph` italic orange? If not, add one (but only one per screen).
- Are all numbers in Goudy?
- Is there exactly one primary (orange) CTA in the viewport?
- Does the page use `var(--bg)` as background, not a hand-picked hex?
- If a logo appears, is it sky-on-navy or white-on-navy — never orange logo on an orange surface?
